import java.awt.*;
import javax.swing.*;
/**

 * Dieses Programm zeichnet 3 verschiedene 3x3 Blöcke, mit jeweils verschiedenen farbig gefüllten
 * Kreisen.

 * Hierbei wird im oberen Block der Farbwert von Blau auf 0, im mittleren Block auf 127 und
 * im letzten Block auf 255(max) gesetzt.

 * @author David L. Reimer [EF]

 * @version 1.0
 * @since 25.01.2018, 13:55 Uhr

 */

public class Zeichenbrett extends JApplet {
    int x = 50;
    int y = 50;
    int count = 0;
    int row = 0;
    int rd = 0;  //rotwert
    int grn = 0;  //grünwert
    int bl = 0;  //blauwert
    
    public void paint(Graphics g){
        
    /* OBERER BLOCK */
            while (count<9) {
                while (row<3){
                    g.setColor(new Color(rd,grn,bl));
                    g.fillOval(x,y,40,40);
                    g.setColor(Color.BLACK);    //farbsetzung rand
                    g.drawOval(x,y,40,40);
                    x += 42;    // 40 = Kreisdurchmesser + 2 für 1 Pixel Abstand
                    rd += 127;
                    row++;
                    count++;
                }
                row = 0;
                rd = 0;
                grn += 127;
                x = 50; 
                y += 42;    // 40 = Kreisdurchmesser + 2 für 1 Pixel Abstand
            }
            grn = 0;
            bl = 127;
    /* MITTLERER BLOCK */
            while (count<18) {
                x = 176;    //x ist auf 176 gesetzt, um Abstand zum oberen Block zu haben.
                while (row<3){
                    g.setColor(new Color(rd,grn,bl));
                    g.fillOval(x,y,40,40);
                    g.setColor(Color.BLACK);    //farbsetzung rand
                    g.drawOval(x,y,40,40);
                    x += 42;    // 40 = Kreisdurchmesser + 2 für 1 Pixel Abstand
                    rd += 127;
                    row++;
                    count++;
                }
                row = 0;
                rd = 0;
                grn += 127;
                x = 176;
                y += 42;    // 40 = Kreisdurchmesser + 2 für 1 Pixel Abstand
            }
            grn = 0;
            bl = 255;
    /* LETZER BLOCK */
            while (count<27) {
                x = 302;    //x ist auf 302 gesetzt, um 30 Pixel Abstand zum linken Rand zu haben.
                while (row<3){
                    g.setColor(new Color(rd,grn,bl));
                    g.fillOval(x,y,40,40);
                    g.setColor(Color.BLACK);    //farbsetzung rand
                    g.drawOval(x,y,40,40);
                    x += 42;    // 40 = Kreisdurchmesser + 2 für 1 Pixel Abstand
                    rd += 127;
                    row++;
                    count++;
                }
                row = 0;
                rd = 0;
                grn += 127;
                x = 302;
                y += 42;    // 40 
            }
    
    }
    
}